package types

const (
	EventTypeLockedSendToVestingAccount = "locked_send_to_vesting_account"

	AttributeKeyUnlocker = "unlocker"
)
