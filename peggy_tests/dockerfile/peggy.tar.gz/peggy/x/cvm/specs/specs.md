# CVM

This spec is a work in progress.

The `cvm` module is largely based on [Hyperledger Burrow](https://github.com/hyperledger/burrow). Please see [their documentation](https://hyperledger.github.io/burrow/) for more information.
