package types

const (
	EventTypeUnlock = "unlock"
)
