package types

// Libraries is a collection of Library objects.
type Libraries []Library
