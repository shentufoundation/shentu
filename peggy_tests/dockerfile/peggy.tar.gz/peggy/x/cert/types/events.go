package types

const (
	EventTypeCertifyCompilation = "certify_compilation"
	EventTypeCertify            = "certify"
	EventTypeRevokeCertificate  = "revoke_certificate"
)
