package params

// Default simulation operation weights for messages and gov proposals
const (
	DefaultWeightCertifierUpdateProposal int = 5
)
