# Documentation

- [CLI Documentation](cli/README.md)
- [REST API Spec](swagger/index.html)
