# CLI Documentation

- [certikd](certikd/certikd.md): Daemon for running the chain.
- [certikcli](certikcli/certikcli.md): Client for interacting with the chain.
