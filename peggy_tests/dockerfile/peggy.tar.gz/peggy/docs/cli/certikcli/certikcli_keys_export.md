## certikcli keys export

Export private keys

### Synopsis

Export a private key from the local keybase in ASCII-armored encrypted format.

```
certikcli keys export <name> [flags]
```

### Options

```
  -h, --help   help for export
```

### Options inherited from parent commands

```
      --chain-id string          Chain ID of tendermint node
  -e, --encoding string          Binary encoding (hex|b64|btc) (default "hex")
      --home string              directory for config and data (default "~/.certikcli")
      --keyring-backend string   Select keyring's backend (os|file|test) (default "os")
  -o, --output string            Output format (text|json) (default "text")
      --trace                    print out full stack trace on errors
```

### SEE ALSO

* [certikcli keys](certikcli_keys.md)	 - Add or view local private keys


