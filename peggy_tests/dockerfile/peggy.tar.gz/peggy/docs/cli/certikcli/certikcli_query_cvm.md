## certikcli query cvm

Querying commands for the CVM module

### Synopsis

Querying commands for the CVM module

### Options

```
  -h, --help   help for cvm
```

### Options inherited from parent commands

```
      --chain-id string   Chain ID of tendermint node
  -e, --encoding string   Binary encoding (hex|b64|btc) (default "hex")
      --home string       directory for config and data (default "~/.certikcli")
  -o, --output string     Output format (text|json) (default "text")
      --trace             print out full stack trace on errors
```

### SEE ALSO

* [certikcli query](certikcli_query.md)	 - Querying subcommands
* [certikcli query cvm abi](certikcli_query_cvm_abi.md)	 - Get CVM contract code ABI
* [certikcli query cvm address-translate](certikcli_query_cvm_address-translate.md)	 - Translate a Bech32 address to hex and vice versa
* [certikcli query cvm code](certikcli_query_cvm_code.md)	 - Get CVM contract code
* [certikcli query cvm meta](certikcli_query_cvm_meta.md)	 - Get CVM Metadata hash for an address or Metadata for a hash
* [certikcli query cvm storage](certikcli_query_cvm_storage.md)	 - Get CVM storage data
* [certikcli query cvm view](certikcli_query_cvm_view.md)	 - View CVM contract


