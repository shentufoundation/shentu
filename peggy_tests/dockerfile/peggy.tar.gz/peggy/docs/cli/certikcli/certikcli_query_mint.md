## certikcli query mint

Querying commands for the minting module

### Synopsis

Querying commands for the minting module

```
certikcli query mint [flags]
```

### Options

```
  -h, --help   help for mint
```

### Options inherited from parent commands

```
      --chain-id string   Chain ID of tendermint node
  -e, --encoding string   Binary encoding (hex|b64|btc) (default "hex")
      --home string       directory for config and data (default "~/.certikcli")
  -o, --output string     Output format (text|json) (default "text")
      --trace             print out full stack trace on errors
```

### SEE ALSO

* [certikcli query](certikcli_query.md)	 - Querying subcommands
* [certikcli query mint annual-provisions](certikcli_query_mint_annual-provisions.md)	 - Query the current minting annual provisions value
* [certikcli query mint inflation](certikcli_query_mint_inflation.md)	 - Query the current minting inflation value
* [certikcli query mint params](certikcli_query_mint_params.md)	 - Query the current minting parameters


