## certikd tendermint show-node-id

Show this node's ID

### Synopsis

Show this node's ID

```
certikd tendermint show-node-id [flags]
```

### Options

```
  -h, --help   help for show-node-id
```

### Options inherited from parent commands

```
      --home string        directory for config and data (default "~/.certikd")
      --log_level string   Log level (default "main:info,state:info,*:error")
      --trace              print out full stack trace on errors
```

### SEE ALSO

* [certikd tendermint](certikd_tendermint.md)	 - Tendermint subcommands


