## certikd version

Print the app version

### Synopsis

Print the app version

```
certikd version [flags]
```

### Options

```
  -h, --help   help for version
      --long   Print long version information
```

### Options inherited from parent commands

```
      --home string        directory for config and data (default "~/.certikd")
      --log_level string   Log level (default "main:info,state:info,*:error")
      --trace              print out full stack trace on errors
```

### SEE ALSO

* [certikd](certikd.md)	 - CertiK App Daemon (server)


