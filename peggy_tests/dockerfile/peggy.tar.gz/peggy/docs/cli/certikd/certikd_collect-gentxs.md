## certikd collect-gentxs

Collect genesis txs and output a genesis.json file

### Synopsis

Collect genesis txs and output a genesis.json file

```
certikd collect-gentxs [flags]
```

### Options

```
      --gentx-dir string   override default "gentx" directory from which collect and execute genesis transactions; default [--home]/config/gentx/
  -h, --help               help for collect-gentxs
```

### Options inherited from parent commands

```
      --home string        directory for config and data (default "~/.certikd")
      --log_level string   Log level (default "main:info,state:info,*:error")
      --trace              print out full stack trace on errors
```

### SEE ALSO

* [certikd](certikd.md)	 - CertiK App Daemon (server)


