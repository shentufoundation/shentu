## certikd tendermint show-validator

Show this node's tendermint validator info

### Synopsis

Show this node's tendermint validator info

```
certikd tendermint show-validator [flags]
```

### Options

```
  -h, --help            help for show-validator
  -o, --output string   Output format (text|json) (default "text")
```

### Options inherited from parent commands

```
      --home string        directory for config and data (default "~/.certikd")
      --log_level string   Log level (default "main:info,state:info,*:error")
      --trace              print out full stack trace on errors
```

### SEE ALSO

* [certikd tendermint](certikd_tendermint.md)	 - Tendermint subcommands


