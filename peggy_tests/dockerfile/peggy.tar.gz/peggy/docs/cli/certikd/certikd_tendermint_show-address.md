## certikd tendermint show-address

Shows this node's tendermint validator consensus address

### Synopsis

Shows this node's tendermint validator consensus address

```
certikd tendermint show-address [flags]
```

### Options

```
  -h, --help            help for show-address
  -o, --output string   Output format (text|json) (default "text")
```

### Options inherited from parent commands

```
      --home string        directory for config and data (default "~/.certikd")
      --log_level string   Log level (default "main:info,state:info,*:error")
      --trace              print out full stack trace on errors
```

### SEE ALSO

* [certikd tendermint](certikd_tendermint.md)	 - Tendermint subcommands


