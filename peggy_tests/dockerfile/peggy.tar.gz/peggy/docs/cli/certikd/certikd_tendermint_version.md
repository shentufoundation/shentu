## certikd tendermint version

Print tendermint libraries' version

### Synopsis

Print protocols' and libraries' version numbers
against which this app has been compiled.


```
certikd tendermint version [flags]
```

### Options

```
  -h, --help   help for version
```

### Options inherited from parent commands

```
      --home string        directory for config and data (default "~/.certikd")
      --log_level string   Log level (default "main:info,state:info,*:error")
      --trace              print out full stack trace on errors
```

### SEE ALSO

* [certikd tendermint](certikd_tendermint.md)	 - Tendermint subcommands


